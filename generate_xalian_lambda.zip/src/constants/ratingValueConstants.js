module.exports = {
    VERY_HIGH: "very high",
    HIGH: "high",
    MEDIUM: "medium",
    LOW: "low",
    VERY_LOW: "very low",
    UNSET: ""
}