module.exports = {
    BASE_BOTTOM_VAR: 50
}