module.exports = class Stat {

    constructor() {
        this.name = "";
        this.points = null;
        this.rating = null;
        this.percentage = null;
    }

}
