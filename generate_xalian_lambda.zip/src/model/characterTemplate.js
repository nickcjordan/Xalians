const constants = require('../constants/constants.js');

module.exports = class XalianTemplate {

    constructor() {
        // this.standardAttackPoints = constants.LOW_THRESHOLD;
		// this.specialAttackPoints = constants._THRESHOLD;
		// this.standardDefensePoints = constants._THRESHOLD;
		// this.specialDefensePoints = constants._THRESHOLD;
		// this.speedPoints = constants._THRESHOLD;
		// this.evasionPoints = constants._THRESHOLD;
		// this.healthPoints = constants._THRESHOLD;
		// this.staminaPoints = constants._THRESHOLD;
		// this.recoveryPoints = constants._THRESHOLD;
    }
}
