const xalianBuilder = require('./xalianBuilder.js');
const translator = require('./translator.js');

// module.exports.handler = async (event) => {
//     // console.log('Event: ', event);

//     let xalian = xalianBuilder.buildXalian();
//     let translatedXalian = translator.translateCharacterToPresentableType(xalian);
//     return {
//         statusCode: 200,
//         headers: {
//             "Content-Type" : "application/json",
//             "Access-Control-Allow-Headers" : "*",
//             "Access-Control-Allow-Methods" : "*",
//             "Access-Control-Allow-Credentials" : true,
//             "Access-Control-Allow-Origin" : "*",
//             "X-Requested-With" : "*"
//         },
//         body: JSON.stringify(translatedXalian)
//     }
// }

'use strict';

const AWS = require('aws-sdk');

AWS.config.setPromisesDependency(require('bluebird'));

const dynamoDb = new AWS.DynamoDB.DocumentClient();


module.exports.submit = (event, context, callback) => {
    const requestBody = JSON.parse(event.body);
    const username = requestBody.username;
    const score = requestBody.score;
  
    submitRecord(scoreRecord(username, score))
      .then(res => {
        callback(null, {
          statusCode: 200,
          body: JSON.stringify({
            message: `Sucessfully submitted record :: username=${username} :: score=${score}`,
            recordId: res.id
          })
        });
      })
      .catch(err => {
        console.log(err);
        callback(null, {
          statusCode: 500,
          body: JSON.stringify({
            message: `Unable to submit record :: username=${username} :: score=${score}`
          })
        })
      });
  };


  const submitRecord = record => {
    console.log('Submitting record');
    const scoreRecord = {
      TableName: process.env.SCORE_TABLE,
      Item: record,
    };
    return dynamoDb.put(scoreRecord).promise()
      .then(res => record);
  };
  
  const scoreRecord = (username, score) => {
    const timestamp = new Date().getTime();
    return {
      id: generateUUID(),
      username: username,
      score: score,
      submittedAt: timestamp,
      updatedAt: timestamp,
    };
  };