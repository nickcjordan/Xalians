module.exports = {
    HIGH: "high",
    MEDIUM: "medium",
    LOW: "low",
    UNSET: ""
}