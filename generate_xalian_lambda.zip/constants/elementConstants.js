module.exports = {
    AIR: "Air",
    BOTANICAL: "Botanical",
    CHEMICAL: "Chemical",
    DARK: "Dark",
    ELECTRICAL: "Electrical",
    EXPLOSIVE: "Explosive",
    FIRE: "Fire",
    GEOLOGICAL: "Geological",
    LIGHT: "Light",
    PSYCHIC: "Psychic",
    SPECTRAL: "Spectral",
    WATER: "Water"
}











